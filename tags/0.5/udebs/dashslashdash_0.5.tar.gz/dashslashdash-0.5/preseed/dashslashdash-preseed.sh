#!/bin/sh

log () {
	logger -t preseed "$@"
}

error () {
	error="$1"
	location="$2"
	db_subst preseed/$error LOCATION "$location"
	db_input critical preseed/$error || true
	db_go || true
	exit 1
}

loc_filename() {
  expr "$1" : '\(.*[^|?]\)|*?*$'
}
loc_is_optional() {
  expr "$1" : '.*[^|?]|*?$' > /dev/null
}
loc_is_substitution() {
  expr "$1" : '.*[^|?]|?*$' > /dev/null
}
# dodgy hack to implement the dsd:// URL type as something that
# hunts for local dsd files before falling back to the main site
dsd_preseed_fetch() {
  local url=$1
  echo "dsd_preseed_fetch: getting $url" >&2

  local urltail
  if urltail=$(expr "$url" : "dsd://\(.*\)")
  then
    db_get netcfg/get_domain
    local domain=$RET
    if [ -n "$domain" -a "$domain" != "unnassigned-domain" ]
    then
      url="http://debian-dsd-preseed.$domain/d-i/$urltail"
    else
      url="http://svn.hands.com/d-i/$urltail"
    fi
  fi

  echo "dsd_preseed_fetch:     from $url" >&2
  preseed_fetch "$url" "$2"
}

# Note: Needs a preseed_fetch function or command not provided by this
# file, as well as preseed_relative
preseed_location () {
	local location="$1"
	
	local tmp=/tmp/debconf-seed
	local logfile=/var/log/debconf-seed
	
	if ! dsd_preseed_fetch $(loc_filename $location) $tmp; then
		if loc_is_optional $location ; then
			# if the file's optional, make the preseed empty
			> $tmp
		else
			error retrieve_error "$location"
		fi
	fi

	if loc_is_substitution $location; then
		mv $tmp $tmp.subst
		chmod +x $tmp.subst
		echo "# --- Output from executing: $location" > $tmp
		if ! $tmp.subst >> $tmp 2> $tmp.stderr ; then
			error substitution_error "$location"
		fi
		mv $tmp.stderr /var/log/$(echo "$location"|tr '/|' '_').stderr
	fi

	db_set preseed/include ""
	db_set preseed/include_command ""
	if ! debconf-set-selections $tmp; then
		error load_error "$location"
	fi
		
	if [ -e $logfile ]; then
		cat $tmp >> $logfile
	else
		cp $tmp $logfile
	fi
	rm -f $tmp

	log "successfully loaded preseed file from $location"
	local last_location="$location"
	
	db_get preseed/include
	local include="$RET"
	db_get preseed/include_command
	if [ -n "$RET" ]; then
		include="$include $(eval $RET)" || true # TODO error handling?
	fi
	
	for location in $include; do
		# Support relative paths, just use path of last file.
		if preseed_relative "$location"; then
			# This works for urls too.
			location="$(dirname $last_location)/$location"
		fi
		if [ -n "$location" ]; then
			preseed_location "$location"
		fi
	done
}
	
preseed () {
	template="$1"

	db_get $template
	location="$RET"
	if [ -n "$location" ]; then
		for loc in $location; do
			preseed_location "$loc"
		done
	fi
}
