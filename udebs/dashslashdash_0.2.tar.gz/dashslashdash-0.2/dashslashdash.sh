#!/bin/sh

# initrd preseed script (only works in conjunction with dashslashdash udeb)
#
# Copyright (c) 2005 Hands.com Ltd

cat <<!EOF!
d-i     debconf/priority        string critical
d-i     netcfg/choose_interface select auto
d-i     netcfg/get_hostname     string unassigned-hostname
d-i     netcfg/get_domain       string unnassigned-domain
d-i     netcfg/wireless_wep     string 
!EOF!

classes="$(debconf-get -/-)"
url="$(debconf-get -/url)"

# magic URL of "svn" points us at the subversion repository
[ svn = "$url" ] && url="http://svn.hands.com/d-i"

if [ -n "$(debconf-get preseed/url)" ] ;
then
  echo "d-i preseed/include_command string dsd-subst/first.cfg"
else
  if [ -r /hd-media/dsd-subst/first.cfg -a -z "$url" ] ; then
    echo "d-i preseed/include_command string /hd-media/dsd-subst/first.cfg"
  else
    # if no URL specified, default to hands.com
    [ -z "$url" ] && url="http://hands.com/d-i"
    echo "d-i preseed/url string $url/dsd-subst/first.cfg"
  fi
fi

echo "local local/di-url string $url"
echo "local local/classes string $classes"
