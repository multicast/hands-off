#!/bin/sh

# initrd preseed script (only works in conjunction with dashslashdash udeb)
#
# Copyright (c) 2005 Hands.com Ltd

cat <<!EOF!
d-i     debconf/priority        string critical
d-i     netcfg/choose_interface select auto
d-i     netcfg/get_hostname     string unassigned-hostname
d-i     netcfg/get_domain       string unnassigned-domain
d-i     netcfg/wireless_wep     string 
!EOF!

classes="$(debconf-get -/- || true)"
url="$(debconf-get -/url || true)"

# magic URL of "svn" points us at the subversion repository
[ svn = "$url" ] && url="http://svn.hands.com/d-i"

if [ -n "$(debconf-get preseed/url || true)" ] ;
then
  echo "d-i preseed/include string dsd/0-first.sh|"
else
  if [ -r /hd-media/dsd/0-first.sh -a -z "$url" ] ; then
    echo "d-i preseed/include string /hd-media/dsd/0-first.sh|"
  else
    # if no URL specified, default to hands.com
    [ -z "$url" ] && url="http://hands.com/d-i"
    echo "d-i preseed/url string $url/dsd/0-first.sh|"
  fi
fi

echo "local local/di-url string $url"
echo "local local/classes string $classes"
